﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using CustomerManagement.ExternalServices.Configuration;
using CustomerManagement.ExternalServices.Clients;

namespace CustomerManagement.ExternalServices
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddExternalServices(
            this IServiceCollection services, IConfiguration configuration)
        {
            services.Configure<TwilioSettings>(configuration.GetSection("Twilio"));
            services.Configure<SendGridSettings>(configuration.GetSection("SendGrid"));
            services.AddHttpClient<ISendGridClient, SendGridClient>();
            services.AddHttpClient<ITwilioClient, TwilioClient>();
            return services;
        }
    }
}