﻿namespace CustomerManagement.ExternalServices.DTOs.Twilio
{
    public class PhoneValidationRequest
    {
        public required string PhoneNumber { get; set; }
    }
}