﻿using System;
using Microsoft.Extensions.DependencyInjection;
using CustomerManagement.Repository.Services;
using Microsoft.Extensions.Configuration;

namespace CustomerManagement.Repository
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddRepositoryServices(
            this IServiceCollection services, IConfiguration configuration)
        {
            var connectionString = configuration.GetConnectionString("DefaultConnection")
                                        ?? throw new InvalidOperationException("Connection string 'DefaultConnection' not found.");
            services.AddScoped<ICustomerRepo>(provider => new CustomerRepo(connectionString));
            return services;
        }
    }
}